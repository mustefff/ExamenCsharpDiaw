﻿using System;
using System.Collections.Generic;

namespace GestionPharmacie
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialisation de la pharmacie avec quelques produits
            List<Produit> produits = new List<Produit>();
            produits.Add(new Produit("Aspirine", 100, 1005));
            produits.Add(new Produit("Paracétamol", 50, 1223));
            produits.Add(new Produit("Ibuprofène", 75, 3550));
            Pharmacien pharmacien = new Pharmacien("Mustafa", "Diaw", produits);

            // Menu principal
            while (true)
            {
                Console.WriteLine("1. Ajouter un produit");
                Console.WriteLine("2. Supprimer un produit");
                Console.WriteLine("3. Modifier un produit");
                Console.WriteLine("4. Afficher les produits");
                Console.WriteLine("5. Effectuer une vente");
                Console.WriteLine("6. Afficher le rapport de vente");
                Console.WriteLine("7. Quitter");
                Console.Write("Entrez votre choix : ");
                string choix = Console.ReadLine();
                Console.WriteLine();

                switch (choix)
                {
                    case "1":
                        pharmacien.AjouterProduit();
                        break;
                    case "2":
                        pharmacien.SupprimerProduit();
                        break;
                    case "3":
                        pharmacien.ModifierProduit();
                        break;
                    case "4":
                        pharmacien.AfficherProduits();
                        break;
                    case "5":
                        pharmacien.EffectuerVente();
                        break;
                    case "6":
                        pharmacien.AfficherRapportVente();
                        break;
                    case "7":
                        return;
                    default:
                        Console.WriteLine("Choix invalide !");
                        break;
                }

                Console.WriteLine();
            }
        }
    }
}