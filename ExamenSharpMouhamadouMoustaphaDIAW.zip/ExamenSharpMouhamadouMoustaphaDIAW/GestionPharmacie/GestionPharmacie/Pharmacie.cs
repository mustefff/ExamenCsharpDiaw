﻿using System;
using System.Collections.Generic;

namespace GestionPharmacie
{
    class Pharmacien
    {
        public string Nom { get; set; }
        public string Prenom { get; set; }
        private List<Produit> produits = new List<Produit>();
        private List<Vente> ventes = new List<Vente>();

        public Pharmacien(string nom, string prenom, List<Produit> produits)
        {
            Nom = nom;
            Prenom = prenom;
            this.produits = produits;
        }

        public void AjouterProduit()
        {
            Console.Write("Entrez le nom du produit : ");
            string nom = Console.ReadLine();
            Console.Write("Entrez la quantité : ");
            int quantite = Convert.ToInt32(Console.ReadLine());
            Console.Write("Entrez le prix unitaire : ");
            double prixUnitaire = Convert.ToDouble(Console.ReadLine());
            produits.Add(new Produit(nom, quantite, prixUnitaire));
            Console.WriteLine("Le produit a été ajouté avec succès.");
        }

        public void SupprimerProduit()
        {
            Console.Write("Entrez le nom du produit à supprimer : ");
            string nom = Console.ReadLine();
            Produit produit = produits.Find(p => p.Nom == nom);
            if (produit != null)
            {
                produits.Remove(produit);
                Console.WriteLine("Le produit a été supprimé avec succès.");
            }
            else
            {
                Console.WriteLine("Le produit n'a pas été trouvé.");
            }
        }

        public void ModifierProduit()
        {
            Console.Write("Entrez le nom du produit à modifier : ");
            string nom = Console.ReadLine();
            Produit produit = produits.Find(p => p.Nom == nom);
            if (produit != null)
            {
                Console.Write("Entrez la nouvelle quantité : ");
                int quantite = Convert.ToInt32(Console.ReadLine());
                Console.Write("Entrez le nouveau prix unitaire : ");
                double prixUnitaire = Convert.ToDouble(Console.ReadLine());
                produit.Quantite = quantite;
                produit.PrixUnitaire = prixUnitaire;
                Console.WriteLine("Le produit a été modifié avec succès.");
            }
            else
            {
                Console.WriteLine("Le produit n'a pas été trouvé.");
            }
        }

        public void AfficherProduits()
        {
            Console.WriteLine("Liste des produits :");
            Console.WriteLine("Nom\tQuantité\tPrix unitaire");
            foreach (Produit produit in produits)
            {
                Console.WriteLine("{0}\t{1}\t\t{2}", produit.Nom, produit.Quantite, produit.PrixUnitaire);
            }
        }

        public void EffectuerVente()
        {
            Console.Write("Entrez le nom du produit vendu : ");
            string nom = Console.ReadLine();
            Produit produit = produits.Find(p => p.Nom == nom);
            if (produit != null)
            {
                Console.Write("Entrez la quantité : ");
                int quantite = Convert.ToInt32(Console.ReadLine());
                if (quantite <= produit.Quantite)
                {
                    double prixTotal = quantite * produit.PrixUnitaire;
                    produit.Quantite -= quantite;
                    ventes.Add(new Vente(nom, quantite, prixTotal));
                    Console.WriteLine("La vente a été effectuée avec succès.");
                }
                else
                {
                    Console.WriteLine("La quantité demandée est supérieure à la quantité en stock.");
                }
            }
            else
            {
                Console.WriteLine("Le produit n'a pas été trouvé.");
            }
        }

        public void AfficherRapportVente()
        {
            Console.WriteLine("Rapport de vente :");
            Console.WriteLine("Nom\tQuantité\tPrix total");
            foreach (Vente vente in ventes)
            {
                Console.WriteLine("{0}\t{1}\t\t{2}", vente.NomProduit, vente.Quantite, vente.PrixTotal);
            }
        }
    }

    class Produit
    {
        public string Nom { get; set; }
        public int Quantite { get; set; }
        public double PrixUnitaire { get; set; }

        public Produit(string nom, int quantite, double prixUnitaire)
        {
            Nom = nom;
            Quantite = quantite;
            PrixUnitaire = prixUnitaire;
        }
    }

    class Vente
    {
        public string NomProduit { get; set; }
        public int Quantite { get; set; }
        public double PrixTotal { get; set; }

        public Vente(string nomProduit, int quantite, double prixTotal)
        {
            NomProduit = nomProduit;
            Quantite = quantite;
            PrixTotal = prixTotal;
        }
    }
}